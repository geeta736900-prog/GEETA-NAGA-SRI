print("Hello World!")
print("Welcome to Python")
print("Geeta naga sri")
print("Iam learning Python")
print("Python Programming")
print("Good Morning")
print("Welcome Students")
print("Python is easy")
print("My first Program")
print("Hello from Python!")


print("2 + 5")
print(2 + 5)
print("10 - 3")
print(10 - 3)
print("Hello World")

print("10 + 20")
print(10 +20)


name = "Geeta"
age = 20
marks = 85
price = 99.5
city = "Chennai"
score = 95
x = 10
message = "Welcome"
a = 10
b = 20


print(f"{name} ")
print(f"{age}")
print(f"{marks} ")
print(f"{price} ")
print(f"{city} ")
print(f"{score} ")
print(f"{x} ")
print(f"{message} ")
print(f"{a + b} ")


word = "Python"
part = word[:0]
print(part)




